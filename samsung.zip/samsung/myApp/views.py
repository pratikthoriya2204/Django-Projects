from django.shortcuts import render,HttpResponse

# Create your views here.

def index(requast):
    return render(requast,"home.html")
    # return HttpResponse("<h1>Hello this is Home page</h1>")